import React from 'react'

export default function Footer() {
  return (
    < >
      <footer className="bg-light text-center text-lg-start">
  {/* Copyright */}
  <div
    className="text-center p-3"
    style={{ backgroundColor: "rgba(0, 0, 0, 0.2)",position:"absolute", bottom:'-15px',width:'1325px' }}
  >
    © 2023 Copyright:
    <a className="text-dark" href="">
      Products.com
    </a>
  </div>
  {/* Copyright */}
</footer>


     </ >
  )
}
