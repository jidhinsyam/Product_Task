import React from 'react'
import Homenav from '../nav/Homenav'
import Footer from '../Footer/Footer'

export default function Basesection() {
  return (
    <>
    <Homenav/>
    <div >
    

 


    </div>

     <Footer/>
    </ >
  )
}

