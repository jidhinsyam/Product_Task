import React from 'react'
import Allproductview from '../components/view/Allproductview'

export default function Allproduct() {
  return (
    < > 
    <Allproductview/>
    </ >
  )
}
