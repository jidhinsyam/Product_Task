import React from 'react'
import Subcategoryelec from '../components/forms/Subcategoryelec'
 
export default function Subcategory() {
  return (
    < > 
    <Subcategoryelec/>
    </ >
  )
}
