import React from 'react'
import Productform from '../components/forms/Productform'

export default function Product() {
  return (
    < > 
    <Productform/>
    </ >
  )
}
