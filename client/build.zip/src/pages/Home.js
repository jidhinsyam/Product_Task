import React from 'react'
import Homenav from '../components/nav/Homenav'
import Basesection from '../components/basesection/Basesection'
import Footer from '../components/Footer/Footer'

export default function Home() {
  return (
    < > 
    
    {/* <Homenav/> */}
    <Basesection/> 
    {/* <Footer/> */}
    </ >
  )
}
