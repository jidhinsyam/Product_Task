import React from 'react'
import Categories from '../components/forms/Categories'

export default function Categoriest() {
  return (
    < >
    
    <Categories/>
    
     </ >
  )
}
